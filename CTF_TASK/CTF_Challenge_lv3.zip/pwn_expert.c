#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void shell() {
    setreuid(geteuid(), getegid());
    system("/bin/sh");
}

void vuln() {
    char buf[32];
    printf("输入你的数据: ");
    gets(buf);
}

int main() {
    setbuf(stdout, NULL);
    printf("地址泄露: %p\n", &shell);
    vuln();
    return 0;
}