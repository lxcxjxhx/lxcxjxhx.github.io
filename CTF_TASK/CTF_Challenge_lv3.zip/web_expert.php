<?php
error_reporting(0);
highlight_file(__FILE__);

if(isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username === 'admin' && password_verify($password, '$2y$10$.eE1E8JdEhWQ7G5KzN8LUOFzQlOHB4JwV8Me/90vFHR3cL7qVTuFm')) {
        echo 'Flag: flag{bcrypt_password_bypass}';
    } else {
        echo '登录失败！';
    }
} else {
    echo '请输入用户名和密码！';
}
?>