import random

key = [random.randint(0, 255) for _ in range(16)]
ciphertext = [ord(c) ^ key[i % len(key)] for i, c in enumerate("SuperSecretFlag")]

print(f"密文: {ciphertext}")
# 你能找出 key 并解密吗？
