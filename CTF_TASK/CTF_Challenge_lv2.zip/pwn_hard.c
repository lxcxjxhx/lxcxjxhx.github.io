#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void shell() { system("/bin/sh"); }

void vuln() {
    char buf[64];
    printf("输入你的数据: ");
    gets(buf);
}

int main() {
    setbuf(stdout, NULL);
    vuln();
    return 0;
}