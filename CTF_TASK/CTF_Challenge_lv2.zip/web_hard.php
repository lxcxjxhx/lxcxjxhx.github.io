<?php
if(isset($_GET['input'])) {
    $input = $_GET['input'];
    if(preg_match('/[0-9]+/', $input) && !preg_match('/[^a-zA-Z0-9]/', $input)) {
        if(md5($input) === md5('admin')) {
            echo 'Flag: flag{bypass_md5_comparison}';
        } else {
            echo '认证失败！';
        }
    } else {
        echo '输入格式不正确！';
    }
} else {
    echo '请提供 input 参数！';
}
?>