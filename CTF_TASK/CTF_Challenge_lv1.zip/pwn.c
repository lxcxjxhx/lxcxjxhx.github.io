#include <stdio.h>
#include <string.h>
void win() { printf("恭喜，你成功了！\n"); }
void vuln() { char buf[32]; gets(buf); }
int main() { vuln(); return 0; }