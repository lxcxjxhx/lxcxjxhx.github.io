cipher = 'jgnnq' 
print(''.join([chr(ord(c)-2) for c in cipher]))  # 你能找到明文吗？